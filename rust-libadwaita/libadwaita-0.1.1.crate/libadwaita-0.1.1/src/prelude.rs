#[doc(hidden)]
pub use gtk::prelude::*;

pub use crate::auto::traits::*;
