use crate::models::Icon;

use gtk::gio::prelude::*;
use gtk::{gio, glib, subclass::prelude::*};

mod imp {
    use super::*;
    use once_cell::sync::Lazy;
    use std::cell::{Cell, RefCell};

    #[derive(Clone, Debug)]
    pub struct IconsGroup {
        pub name: RefCell<Option<String>>,
        pub icons: gio::ListStore,
        pub is_system: Cell<bool>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for IconsGroup {
        const NAME: &'static str = "IconsGroup";
        type Type = super::IconsGroup;

        fn new() -> Self {
            let icons = gio::ListStore::new(Icon::static_type());
            Self {
                icons,
                name: RefCell::new(None),
                is_system: Cell::new(false),
            }
        }
    }

    impl ObjectImpl for IconsGroup {
        fn properties() -> &'static [glib::ParamSpec] {
            static PROPERTIES: Lazy<Vec<glib::ParamSpec>> = Lazy::new(|| {
                vec![
                    glib::ParamSpecString::new("name", "Name", "Name", None, glib::ParamFlags::READWRITE),
                    glib::ParamSpecObject::new("icons", "icons", "Icons", gio::ListStore::static_type(), glib::ParamFlags::READABLE),
                ]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &glib::Value, pspec: &glib::ParamSpec) {
            match pspec.name() {
                "name" => {
                    let name = value.get().unwrap();
                    self.name.replace(name);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &glib::ParamSpec) -> glib::Value {
            match pspec.name() {
                "name" => self.name.borrow().to_value(),
                "icons" => self.icons.to_value(),
                _ => unimplemented!(),
            }
        }
    }
}
glib::wrapper! {
    pub struct IconsGroup(ObjectSubclass<imp::IconsGroup>);
}

impl IconsGroup {
    pub fn new(name: &str) -> Self {
        glib::Object::new(&[("name", &name)]).expect("Failed to create row data")
    }

    pub fn add_icons(&self, icons: Vec<Icon>) {
        self.imp().icons.splice(0, 0, icons.as_slice());
    }

    pub fn icons(&self) -> gio::ListStore {
        self.imp().icons.clone()
    }

    pub fn name(&self) -> String {
        self.imp().name.borrow().clone().unwrap()
    }

    pub fn is_system(&self) -> bool {
        self.imp().is_system.get()
    }

    pub fn set_is_system(&self, is_system: bool) {
        self.imp().is_system.replace(is_system);
    }
}
