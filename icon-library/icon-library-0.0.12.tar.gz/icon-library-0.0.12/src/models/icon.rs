use gtk::gio::prelude::*;
use gtk::{gdk, gdk_pixbuf, gio, glib, gsk, prelude::*, subclass::prelude::*};
use once_cell::sync::Lazy;
use serde::de;
use serde::Deserialize;
use std::cell::RefCell;

#[derive(Clone, Debug, Deserialize)]
pub struct IconJson {
    #[serde(deserialize_with = "icon_name")]
    pub name: String,
    pub tags: Vec<String>,
    pub context: String,
}

fn icon_name<'de, D>(deserializer: D) -> Result<String, D::Error>
where
    D: de::Deserializer<'de>,
{
    let icon = String::deserialize(deserializer)?;
    let icon_name = format!("{}-symbolic", icon);
    Ok(icon_name)
}
mod imp {
    use super::*;
    use std::cell::Cell;

    #[derive(Debug, Default)]
    pub struct Icon {
        pub name: RefCell<Option<String>>,
        pub tags: RefCell<Vec<String>>,
        pub context: RefCell<Option<String>>,
        pub is_system: Cell<Option<bool>>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for Icon {
        const NAME: &'static str = "Icon";
        type Type = super::Icon;
    }

    impl ObjectImpl for Icon {
        fn properties() -> &'static [glib::ParamSpec] {
            static PROPERTIES: Lazy<Vec<glib::ParamSpec>> = Lazy::new(|| {
                vec![
                    glib::ParamSpecString::new(
                        "name",
                        "Name",
                        "Name",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new("context", "context", "Context", None, glib::ParamFlags::READWRITE),
                    glib::ParamSpecValueArray::new(
                        "tags",
                        "tags",
                        "Tags",
                        &glib::ParamSpecString::new(
                            "tag",
                            "Tag",
                            "Tag",
                            None, // Default value
                            glib::ParamFlags::READWRITE,
                        ), // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                ]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &glib::Value, pspec: &glib::ParamSpec) {
            match pspec.name() {
                "name" => {
                    let name = value.get().unwrap();
                    self.name.replace(name);
                }
                "tags" => {
                    let tags = value.get().unwrap();
                    self.tags.replace(tags);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &glib::ParamSpec) -> glib::Value {
            match pspec.name() {
                "name" => self.name.borrow().to_value(),
                "tags" => self.tags.borrow().to_value(),
                _ => unimplemented!(),
            }
        }
    }
}
glib::wrapper! {
    pub struct Icon(ObjectSubclass<imp::Icon>);
}

impl Icon {
    pub fn new(name: &str) -> Self {
        glib::Object::new(&[("name", &name)]).expect("Failed to create row data")
    }

    pub fn name(&self) -> String {
        self.imp().name.borrow().clone().unwrap()
    }

    pub fn tags(&self) -> Vec<String> {
        self.imp().tags.borrow().clone()
    }

    pub fn is_system(&self) -> bool {
        self.imp().is_system.get().unwrap_or(false)
    }

    pub fn set_is_system(&self, is_system: bool) {
        self.imp().is_system.set(Some(is_system));
    }

    pub fn set_tags(&self, tags: Vec<String>) {
        self.imp().tags.replace(tags);
    }

    pub fn should_display(&self, search_str: &str) -> bool {
        let icon_name = self.name().to_lowercase();
        let mut icon_terms = icon_name.split('-');
        // Check if the icon should be shown for the searched string
        let mut found_tags = self.tags();
        found_tags.retain(|tag| tag.to_lowercase().contains(&search_str));

        icon_terms.any(|term| term.contains(&search_str)) || !found_tags.is_empty() || icon_name.contains(&search_str)
    }

    pub fn derive(&self) -> anyhow::Result<()> {
        let icon_file = self.file();
        // Push the icon into /tmp so other apps can access it for now. Not ideal :(
        let mut dest = std::env::temp_dir();
        dest.push(icon_file.basename().unwrap());
        let dest = gio::File::for_path(dest);
        self.save(&dest)?;

        let uri = dest.uri();
        glib::idle_add(move || {
            if let Err(err) = gio::AppInfo::launch_default_for_uri(&uri, None::<&gio::AppLaunchContext>) {
                log::error!("Failed to open the project in Inkscape {}", err);
            }
            glib::Continue(false)
        });
        Ok(())
    }

    pub fn save(&self, destination: &gio::File) -> anyhow::Result<()> {
        let icon_file = self.file();
        icon_file.copy(destination, gio::FileCopyFlags::OVERWRITE, gio::Cancellable::NONE, None)?;
        Ok(())
    }

    pub fn file(&self) -> gio::File {
        self.paintable(-1).file().unwrap()
    }

    pub fn paintable(&self, size: i32) -> gtk::IconPaintable {
        let display = gdk::Display::default().unwrap();
        let theme = gtk::IconTheme::for_display(&display);
        theme.lookup_icon(&self.name(), &[], size, 1, gtk::TextDirection::Ltr, gtk::IconLookupFlags::FORCE_SYMBOLIC)
    }

    /// Returns a pixbuf for use in GNOME Shell.
    pub fn pixbuf(&self) -> Option<gdk_pixbuf::Pixbuf> {
        const SIZE: i32 = 24;
        let snapshot = gtk::Snapshot::new();
        let paintable = self.paintable(SIZE);

        // Colors displayed by gtk/adw in dark mode.
        let fg_color = String::from("#ffffff"); // Light 1
        let error_color = String::from("#ff7b63");
        let warning_color = String::from("#f8e45c"); // Yellow 2
        let success_color = String::from("#8ff0a4"); // Green 1

        let colors = [
            gdk::RGBA::parse(&fg_color).unwrap(),
            gdk::RGBA::parse(&error_color).unwrap(),
            gdk::RGBA::parse(&warning_color).unwrap(),
            gdk::RGBA::parse(&success_color).unwrap(),
        ];

        let renderer = gsk::GLRenderer::new();
        renderer.realize(gdk::Surface::NONE).ok()?;
        paintable.snapshot_symbolic(&snapshot, SIZE.into(), SIZE.into(), &colors);
        let node = snapshot.to_node()?;
        let texture = renderer.render_texture(&node, None);
        renderer.unrealize();

        let bytes = texture.save_to_png_bytes();
        let stream = gio::MemoryInputStream::from_bytes(&bytes);
        gdk_pixbuf::Pixbuf::from_stream(&stream, gio::Cancellable::NONE).ok()
    }

    pub async fn copy(&self) -> anyhow::Result<()> {
        let display = gdk::Display::default().unwrap();
        let clipboard = display.clipboard();

        let file = self.file();
        let (bytes, _) = file.load_contents_future().await?;
        let gbytes = glib::Bytes::from_owned(bytes);
        let content = gdk::ContentProvider::for_bytes("image/svg+xml", &gbytes);
        clipboard.set_content(Some(&content))?;
        Ok(())
    }

    pub fn copy_name(&self) {
        if let Some(display) = gdk::Display::default() {
            let clipboard = display.clipboard();
            clipboard.set_text(&self.name());
        }
    }
}
