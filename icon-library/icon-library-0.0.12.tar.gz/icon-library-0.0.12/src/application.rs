use crate::config;
use crate::models::IconsModel;
use crate::widgets::ExportDialog;
use crate::widgets::Window;

use gettextrs::gettext;
use gtk::glib::clone;
use gtk::{gdk, gio, glib, prelude::*, subclass::prelude::*};
use gtk_macros::action;

use search_provider::{IconData, ResultID, ResultMeta, SearchProvider, SearchProviderImpl};

#[doc(hidden)]
mod imp {
    use super::*;
    use gtk::glib::WeakRef;
    use std::cell::RefCell;

    pub struct Application {
        pub window: RefCell<Option<WeakRef<Window>>>,
        pub model: IconsModel,
        pub settings: gio::Settings,
        pub search_provider: RefCell<Option<SearchProvider<super::Application>>>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for Application {
        const NAME: &'static str = "Application";
        type ParentType = gtk::Application;
        type Type = super::Application;

        fn new() -> Self {
            let settings = gio::Settings::new(config::APP_ID);
            Self {
                settings,
                model: IconsModel::new(),
                window: RefCell::new(None),
                search_provider: RefCell::default(),
            }
        }
    }
    impl ObjectImpl for Application {}
    impl ApplicationImpl for Application {
        fn startup(&self, application: &Self::Type) {
            self.parent_startup(application);

            adw::init();

            let p = gtk::CssProvider::new();
            gtk::CssProvider::load_from_resource(&p, "/org/gnome/design/IconLibrary/style.css");
            if let Some(display) = gdk::Display::default() {
                gtk::StyleContext::add_provider_for_display(&display, &p, gtk::STYLE_PROVIDER_PRIORITY_APPLICATION);
            }

            action!(
                application,
                "quit",
                clone!(@weak application => move |_, _| {
                    application.quit();
                })
            );

            action!(
                application,
                "about",
                clone!(@weak application => move |_, _| {
                    let window = application.active_window().unwrap();
                    gtk::AboutDialog::builder()
                        .program_name(&gettext("Icon Library"))
                        .modal(true)
                        .version(config::VERSION)
                        .comments(&gettext("Symbolic icons for your apps"))
                        .website("https://gitlab.gnome.org/World/design/icon-library")
                        .authors(vec!["Bilal Elmoussaoui".to_string()])
                        .artists(vec!["Jakub Steiner".to_string(), "Tobias Bernard".to_string()])
                        .translator_credits(&gettext("translator-credits"))
                        .logo_icon_name(config::APP_ID)
                        .license_type(gtk::License::Gpl30)
                        .transient_for(&window)
                        .build()
                        .show();
                })
            );

            let dark_mode_action = self.settings.create_action("dark-mode");
            application.add_action(&dark_mode_action);

            self.settings.connect_changed(
                Some("dark-mode"),
                clone!(@weak application => move |_, _| {
                    application.update_color_scheme();
                }),
            );
            application.update_color_scheme();

            let search_provider_path = config::OBJECT_PATH;
            let search_provider_name = format!("{}.SearchProvider", config::APP_ID);

            // Init icon cache used for drag n drop.
            let cache_path = glib::user_cache_dir().join("icon-library").join("icons");
            std::fs::create_dir_all(&cache_path).unwrap_or_else(|err| log::debug!("Could not create cache directory: {}", err));

            // Accels
            application.set_accels_for_action("app.dark-mode", &["<primary>T"]);
            application.set_accels_for_action("app.about", &["<primary>comma"]);
            application.set_accels_for_action("app.quit", &["<primary>q"]);

            let ctx = glib::MainContext::default();
            ctx.spawn_local(clone!(@weak application => async move {
                match SearchProvider::new(application.clone(), search_provider_name, search_provider_path).await {
                    Ok(search_provider) => {
                        application.imp().search_provider.replace(Some(search_provider));
                    },
                    Err(err) => log::debug!("Could not start search provider: {}", err),
                };
            }));

            gtk::Window::set_default_icon_name(config::APP_ID);
        }

        fn activate(&self, application: &Self::Type) {
            let window = application.window();
            window.present();
        }
    }
    impl GtkApplicationImpl for Application {}
}

glib::wrapper! {
    pub struct Application(ObjectSubclass<imp::Application>) @extends gio::Application, gtk::Application, gio::ActionMap;
}

impl Application {
    pub fn run() {
        log::info!("Icon Library({})", config::APP_ID);
        log::info!("Version: {} ({})", config::VERSION, config::PROFILE);
        log::info!("Datadir: {}", config::PKGDATADIR);

        let app = glib::Object::new::<Self>(&[
            ("application-id", &config::APP_ID),
            ("flags", &gio::ApplicationFlags::FLAGS_NONE),
            ("resource-base-path", &Some("/org/gnome/design/IconLibrary")),
        ])
        .unwrap();

        ApplicationExtManual::run(&app);
    }

    fn window(&self) -> Window {
        let imp = self.imp();

        if let Some(ref win) = *imp.window.borrow() {
            return win.upgrade().unwrap();
        }

        let window = Window::new(&imp.model, self);
        imp.window.replace(Some(window.downgrade()));
        window
    }

    fn update_color_scheme(&self) {
        let manager = adw::StyleManager::default();

        if !manager.system_supports_color_schemes() {
            let color_scheme = if self.imp().settings.boolean("dark-mode") {
                adw::ColorScheme::PreferDark
            } else {
                adw::ColorScheme::PreferLight
            };
            manager.set_color_scheme(color_scheme);
        }
    }
}

impl SearchProviderImpl for Application {
    fn activate_result(&self, identifier: ResultID, _terms: &[String], timestamp: u32) {
        let window = self.window();

        // Export the icon
        if let Some(icon) = self.imp().model.get_icon_byname(&identifier) {
            window.present_with_time(timestamp);
            let export_dialog = ExportDialog::new(icon);
            export_dialog.set_transient_for(Some(&window));
            export_dialog.present_with_time(timestamp);
        }
    }

    fn initial_result_set(&self, terms: &[String]) -> Vec<String> {
        let mut icon_names = self.imp().model.search(terms);
        icon_names.sort();
        icon_names
    }

    fn result_metas(&self, identifiers: &[ResultID]) -> Vec<ResultMeta> {
        let model = &self.imp().model;
        identifiers
            .iter()
            .map(clone!(@weak model => @default-panic, move |sp_id| {
                model.get_icon_byname(sp_id).map(|icon| {
                    if let Some(pixbuf) = icon.pixbuf() {
                        let icon_data = IconData::from(&pixbuf);
                        ResultMeta::builder(sp_id.to_string(), sp_id)
                            .clipboard_text(sp_id)
                            .icon_data(icon_data)
                            .build()
                    } else {
                        ResultMeta::builder(sp_id.to_string(), sp_id)
                            .clipboard_text(sp_id)
                            .gicon(sp_id)
                            .build()
                    }
                })
            }))
            .flatten()
            .collect::<Vec<ResultMeta>>()
    }
}
