use crate::application::Application;
use crate::config;
use crate::models::{IconsGroup, IconsModel};
use crate::widgets::icons::IconsGroupWidget;

use gtk::prelude::*;
use gtk::subclass::prelude::*;
use gtk::{
    gio,
    glib::{self, clone},
    CompositeTemplate,
};

mod imp {
    use super::*;
    use adw::subclass::prelude::*;
    use std::cell::RefCell;

    #[derive(Debug, CompositeTemplate)]
    #[template(resource = "/org/gnome/design/IconLibrary/window.ui")]
    pub struct Window {
        pub model: RefCell<Option<IconsModel>>,
        pub settings: gio::Settings,
        #[template_child]
        pub search_entry: TemplateChild<gtk::SearchEntry>,
        #[template_child]
        pub stack: TemplateChild<gtk::Stack>,
        #[template_child]
        pub listbox: TemplateChild<gtk::ListBox>,
        #[template_child]
        pub dark_mode_button: TemplateChild<gtk::Widget>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for Window {
        const NAME: &'static str = "Window";
        type Type = super::Window;
        type ParentType = adw::ApplicationWindow;

        fn new() -> Self {
            let settings = gio::Settings::new(config::APP_ID);
            Self {
                model: RefCell::new(None),
                settings,
                listbox: TemplateChild::default(),
                stack: TemplateChild::default(),
                search_entry: TemplateChild::default(),
                dark_mode_button: TemplateChild::default(),
            }
        }
        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }
        fn instance_init(obj: &gtk::glib::subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for Window {}
    impl WidgetImpl for Window {}
    impl WindowImpl for Window {
        fn close_request(&self, window: &Self::Type) -> gtk::Inhibit {
            if let Err(err) = window.save_state() {
                log::warn!("Failed to save window state {:#?}", err);
            }
            self.parent_close_request(window)
        }
    }
    impl ApplicationWindowImpl for Window {}
    impl AdwApplicationWindowImpl for Window {}
}

glib::wrapper! {
    pub struct Window(ObjectSubclass<imp::Window>)
        @extends gtk::Widget, gtk::Window, gtk::ApplicationWindow, adw::ApplicationWindow, gio::ActionMap;
}

impl Window {
    pub fn new(model: &IconsModel, app: &Application) -> Self {
        let window = glib::Object::new::<Self>(&[("application", app)]).unwrap();
        app.add_window(&window);

        if config::PROFILE == "Devel" {
            window.style_context().add_class("devel");
        }
        window.init(model);
        window
    }

    pub fn init(&self, model: &IconsModel) {
        let imp = self.imp();
        imp.listbox.bind_model(Some(model), move |obj| {
            let icons_group = obj.downcast_ref::<IconsGroup>().unwrap();
            let row = IconsGroupWidget::new(icons_group);
            row.upcast::<gtk::Widget>()
        });

        // Search
        let search_entry = &*imp.search_entry;
        search_entry.set_key_capture_widget(Some(self));

        search_entry.connect_search_started(move |entry| {
            entry.grab_focus();
        });

        search_entry.connect_search_changed(clone!(@weak self as window => move |entry| {
            let search_text = entry.text().to_ascii_lowercase();
            if search_text.is_empty(){
                window.filter(None);
            } else {
                window.filter(Some(search_text));
            }
        }));

        search_entry.connect_stop_search(move |entry| {
            entry.set_text("");
        });

        // Load latest window state
        self.load_state();

        let manager = adw::StyleManager::default();
        imp.dark_mode_button.set_visible(!manager.system_supports_color_schemes());
    }

    fn filter(&self, search_text: Option<String>) {
        let imp = self.imp();
        if let Some(search_text) = search_text {
            imp.listbox.set_filter_func(move |item| {
                let group_widget = item.downcast_ref::<IconsGroupWidget>().unwrap();
                let group = group_widget.group();
                if group.name().to_ascii_lowercase().contains(&search_text) {
                    group_widget.filter(None);
                    true
                } else {
                    group_widget.filter(Some(search_text.clone()));
                    group_widget.n_visible() > 0
                }
            });
        } else {
            imp.listbox.unset_filter_func();
            let mut index = 0;
            while let Some(child) = imp.listbox.row_at_index(index) {
                let group_widget = child.downcast_ref::<IconsGroupWidget>().unwrap();
                group_widget.filter(None);
                index += 1;
            }
        }
        if self.n_visible() == 0 {
            imp.stack.set_visible_child_name("empty");
        } else {
            imp.stack.set_visible_child_name("icons");
        }
    }

    fn n_visible(&self) -> u32 {
        let mut index = 0;
        let mut counter = 0;
        while let Some(child) = self.imp().listbox.row_at_index(index) {
            index += 1;
            // We use is_child_visible since is_visible and get_visible
            // always return true.
            if child.is_child_visible() {
                counter += 1;
            }
        }
        counter
    }

    fn save_state(&self) -> anyhow::Result<()> {
        let settings = &self.imp().settings;
        let size = self.default_size();

        settings.set_int("window-width", size.0)?;
        settings.set_int("window-height", size.1)?;
        settings.set_boolean("is-maximized", self.is_maximized())?;

        Ok(())
    }

    fn load_state(&self) {
        let settings = &self.imp().settings;

        let width = settings.int("window-width");
        let height = settings.int("window-height");

        if width > -1 && height > -1 {
            self.set_default_size(width, height);
        }

        let is_maximized = settings.boolean("is-maximized");

        if is_maximized {
            self.maximize();
        }
    }
}
