use crate::models::{Icon, IconsGroup};
use crate::widgets::icons::IconWidget;
use crate::widgets::ExportDialog;

use gtk::{glib, prelude::*, subclass::prelude::*, CompositeTemplate};

mod imp {
    use super::*;
    use gtk::glib::subclass;
    use once_cell::sync::Lazy;
    use std::cell::RefCell;

    #[derive(Default, Debug, CompositeTemplate)]
    #[template(resource = "/org/gnome/design/IconLibrary/icons_group.ui")]
    pub struct IconsGroupWidget {
        pub group: RefCell<Option<IconsGroup>>,
        #[template_child]
        pub flowbox: TemplateChild<gtk::FlowBox>,
        #[template_child]
        pub name_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub system_icons_label: TemplateChild<gtk::Label>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for IconsGroupWidget {
        const NAME: &'static str = "IconsGroupWidget";
        type Type = super::IconsGroupWidget;
        type ParentType = gtk::ListBoxRow;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for IconsGroupWidget {
        fn properties() -> &'static [glib::ParamSpec] {
            static PROPERTIES: Lazy<Vec<glib::ParamSpec>> = Lazy::new(|| {
                vec![glib::ParamSpecObject::new(
                    "group",
                    "Icon Group",
                    "Icon Group",
                    IconsGroup::static_type(),
                    glib::ParamFlags::READWRITE | glib::ParamFlags::CONSTRUCT_ONLY,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &glib::Value, pspec: &glib::ParamSpec) {
            match pspec.name() {
                "group" => {
                    let group = value.get().unwrap();
                    self.group.replace(group);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &glib::ParamSpec) -> glib::Value {
            match pspec.name() {
                "group" => self.group.borrow().to_value(),
                _ => unimplemented!(),
            }
        }
    }
    impl WidgetImpl for IconsGroupWidget {}
    impl BoxImpl for IconsGroupWidget {}
    impl ListBoxRowImpl for IconsGroupWidget {}
}

glib::wrapper! {
    pub struct IconsGroupWidget(ObjectSubclass<imp::IconsGroupWidget>) @extends gtk::Widget, gtk::Box, gtk::ListBoxRow;
}

impl IconsGroupWidget {
    pub fn new(group: &IconsGroup) -> Self {
        let widget = glib::Object::new::<Self>(&[("group", group)]).unwrap();
        widget.init();
        widget
    }

    pub fn n_visible(&self) -> u32 {
        let mut index = 0;
        let mut counter = 0;
        while let Some(child) = self.imp().flowbox.child_at_index(index) {
            index += 1;
            // We use is_child_visible since is_visible and get_visible
            // always return true.
            if child.is_child_visible() {
                counter += 1;
            }
        }
        counter
    }

    pub fn group(&self) -> IconsGroup {
        self.property::<IconsGroup>("group")
    }

    pub fn filter(&self, search_text: Option<String>) {
        let imp = self.imp();
        if let Some(search_text) = search_text {
            imp.flowbox.set_filter_func(move |row| {
                let icon_widget = row.downcast_ref::<IconWidget>().unwrap();
                icon_widget.icon().should_display(&search_text)
            });
        } else {
            imp.flowbox.unset_filter_func();
        }
    }

    fn init(&self) {
        let imp = self.imp();
        imp.name_label.set_label(&self.group().name());

        let sorter = gtk::CustomSorter::new(|item1, item2| {
            let icon1 = item1.downcast_ref::<Icon>().unwrap();
            let icon2 = item2.downcast_ref::<Icon>().unwrap();

            icon1.name().cmp(&icon2.name()).into()
        });
        let model = gtk::SortListModel::new(Some(&self.group().icons()), Some(&sorter));

        imp.flowbox.bind_model(Some(&model), move |obj| {
            let icon = obj.downcast_ref::<Icon>().unwrap();
            let child = IconWidget::new(icon);
            child.upcast::<gtk::Widget>()
        });

        imp.flowbox
            .connect_child_activated(glib::clone!(@weak self as widget => move |_flowbox, child| {
                    let icon = child.downcast_ref::<IconWidget>().unwrap().icon();
                    let export_dialog = ExportDialog::new(icon);
                    let window = widget.root().unwrap().downcast::<gtk::Window>().unwrap();

                    export_dialog.set_transient_for(Some(&window));
                    export_dialog.show();
            }));

        if imp.group.borrow().as_ref().unwrap().is_system() {
            imp.system_icons_label.show();
        }
    }
}
