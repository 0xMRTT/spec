use crate::models::Icon;

use gtk::{gdk, gio, glib, prelude::*, subclass::prelude::*};

mod imp {
    use super::*;
    use std::cell::RefCell;

    #[derive(Debug, Default)]
    pub struct IconWidget {
        pub image: gtk::Image,
        pub icon: RefCell<Option<Icon>>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for IconWidget {
        const NAME: &'static str = "IconWidget";
        type Type = super::IconWidget;
        type ParentType = gtk::FlowBoxChild;
    }

    impl ObjectImpl for IconWidget {
        fn properties() -> &'static [glib::ParamSpec] {
            use once_cell::sync::Lazy;
            static PROPERTIES: Lazy<Vec<glib::ParamSpec>> = Lazy::new(|| {
                vec![glib::ParamSpecObject::new(
                    "icon",
                    "Icon",
                    "Icon",
                    Icon::static_type(),
                    glib::ParamFlags::READWRITE | glib::ParamFlags::CONSTRUCT_ONLY,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &glib::Value, pspec: &glib::ParamSpec) {
            match pspec.name() {
                "icon" => {
                    let icon = value.get().unwrap();
                    self.icon.replace(icon);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &glib::ParamSpec) -> glib::Value {
            match pspec.name() {
                "icon" => self.icon.borrow().to_value(),
                _ => unimplemented!(),
            }
        }
    }

    impl WidgetImpl for IconWidget {}
    impl FlowBoxChildImpl for IconWidget {}
}

glib::wrapper! {
    pub struct IconWidget(ObjectSubclass<imp::IconWidget>) @implements gtk::Widget, gtk::FlowBoxChild;
}

impl IconWidget {
    pub fn new(icon: &Icon) -> IconWidget {
        let widget = glib::Object::new::<Self>(&[("icon", icon)]).unwrap();
        widget.init();
        widget
    }

    pub fn icon(&self) -> Icon {
        self.property::<Icon>("icon")
    }

    fn init(&self) {
        let imp = self.imp();

        self.set_width_request(48);
        self.set_height_request(48);

        self.set_halign(gtk::Align::Center);
        self.set_valign(gtk::Align::Center);
        self.set_tooltip_text(Some(&self.icon().name()));

        imp.image.set_from_icon_name(Some(&self.icon().name()));
        imp.image.set_pixel_size(32);

        self.set_child(Some(&imp.image));

        let source = gtk::DragSource::new();

        source.connect_prepare(glib::clone!(@weak self as widget => @default-return None, move |_, _, _| {
            match widget.content_provider() {
                Ok(content) => Some(content),
                Err(err) => {
                    log::debug!("Could not get content provider: {:?}", err);
                    None
                }
            }
        }));

        source.connect_drag_begin(glib::clone!(@weak self as widget => move |source, _| {
            let display = gdk::Display::default().unwrap();
            let icon_theme = gtk::IconTheme::for_display(&display);
            let paintable = icon_theme.lookup_icon(&widget.icon().name(), &[], 32, 1, gtk::TextDirection::None, gtk::IconLookupFlags::PRELOAD);
            source.set_icon(Some(&paintable), 0, 0);
        }));

        self.add_controller(&source);
    }

    fn content_provider(&self) -> anyhow::Result<gdk::ContentProvider> {
        let cache_path = glib::user_cache_dir().join("icon-library").join("icons");
        let icon_name = format!("{}.svg", &self.icon().name());

        let file = self.icon().file();
        let dest = gio::File::for_path(cache_path.join(&icon_name));
        file.copy(&dest, gio::FileCopyFlags::OVERWRITE, gio::Cancellable::NONE, None)?;

        let bytes = glib::Bytes::from_owned(file.load_contents(gio::Cancellable::NONE)?.0);

        let svg_content = gdk::ContentProvider::for_bytes("image/svg+xml", &bytes);
        let text_content = gdk::ContentProvider::for_value(&self.icon().name().to_value());
        let file_content = gdk::ContentProvider::for_value(&dest.to_value());

        Ok(gdk::ContentProvider::new_union(&[svg_content, text_content, file_content]))
    }
}
