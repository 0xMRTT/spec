use super::examples::*;
use crate::config;
use crate::models::Icon;
use adw::prelude::*;
use gettextrs::gettext;
use gsv::prelude::*;
use gtk::glib::clone;
use gtk::subclass::prelude::*;
use gtk::{gio, glib, CompositeTemplate};
use gtk_macros::action;
use std::path::Path;

mod imp {
    use super::*;
    use adw::subclass::prelude::*;
    use glib::ParamSpec;
    use once_cell::sync::Lazy;
    use std::cell::RefCell;

    #[derive(Debug, Default, CompositeTemplate)]
    #[template(resource = "/org/gnome/design/IconLibrary/export_dialog.ui")]
    pub struct ExportDialog {
        pub icon: RefCell<Option<Icon>>,
        #[template_child]
        pub icon_size_16: TemplateChild<gtk::Image>,
        #[template_child]
        pub icon_size_32: TemplateChild<gtk::Image>,
        #[template_child]
        pub icon_size_64: TemplateChild<gtk::Image>,
        #[template_child]
        pub languages_stack: TemplateChild<gtk::Stack>,
        #[template_child]
        pub tags_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub window_title: TemplateChild<adw::WindowTitle>,
        #[template_child]
        pub resource_view: TemplateChild<gsv::View>,
        #[template_child]
        pub python_meson_view: TemplateChild<gsv::View>,
        #[template_child]
        pub python_view: TemplateChild<gsv::View>,
        #[template_child]
        pub rust_meson_view: TemplateChild<gsv::View>,
        #[template_child]
        pub rust_main_view: TemplateChild<gsv::View>,
        #[template_child]
        pub vala_meson_view: TemplateChild<gsv::View>,
        #[template_child]
        pub js_meson_view: TemplateChild<gsv::View>,
        #[template_child]
        pub js_view: TemplateChild<gsv::View>,
        #[template_child]
        pub c_meson_view: TemplateChild<gsv::View>,
        #[template_child]
        pub in_app_row: TemplateChild<adw::ActionRow>,
        #[template_child]
        pub as_system_row: TemplateChild<adw::ActionRow>,
        #[template_child]
        pub deck: TemplateChild<adw::Leaflet>,
        #[template_child]
        pub stack: TemplateChild<gtk::Stack>,
        #[template_child]
        pub include_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub toast_overlay: TemplateChild<adw::ToastOverlay>,
        pub scheme: RefCell<Option<gsv::StyleScheme>>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for ExportDialog {
        const NAME: &'static str = "ExportDialog";
        type Type = super::ExportDialog;
        type ParentType = adw::Window;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &gtk::glib::subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for ExportDialog {
        fn constructed(&self, obj: &Self::Type) {
            self.parent_constructed(obj);

            obj.init();
            obj.setup_actions();
        }

        fn properties() -> &'static [ParamSpec] {
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![glib::ParamSpecObject::new(
                    "icon",
                    "Icon",
                    "The to be exported icon",
                    Icon::static_type(), // Default value
                    glib::ParamFlags::READWRITE | glib::ParamFlags::CONSTRUCT,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &glib::Value, pspec: &ParamSpec) {
            match pspec.name() {
                "icon" => {
                    let icon = value.get().unwrap();
                    self.icon.replace(icon);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "icon" => self.icon.borrow().to_value(),
                _ => unimplemented!(),
            }
        }
    }
    impl WidgetImpl for ExportDialog {}
    impl WindowImpl for ExportDialog {}
    impl AdwWindowImpl for ExportDialog {}
}

glib::wrapper! {
    pub struct ExportDialog(ObjectSubclass<imp::ExportDialog>)
        @extends gtk::Widget, gtk::Window, adw::Window;
}

impl ExportDialog {
    pub fn new(icon: Icon) -> Self {
        glib::Object::new(&[("icon", &icon)]).unwrap()
    }

    fn create_buffer(&self, lang: &gsv::Language, content: &str, view: &gsv::View) -> gsv::Buffer {
        let buffer = gsv::Buffer::with_language(lang);
        view.set_buffer(Some(&buffer));
        buffer.set_highlight_syntax(true);
        buffer.set_highlight_matching_brackets(false);
        TextBufferExt::set_text(&buffer, content);

        buffer
    }

    fn icon(&self) -> Icon {
        self.imp().icon.borrow().as_ref().unwrap().clone()
    }

    fn apply_color_scheme(&self, view: &gsv::View) {
        let buffer = view.buffer().downcast::<gsv::Buffer>().unwrap();
        buffer.set_style_scheme(Some(self.imp().scheme.borrow().as_ref().unwrap()));
    }

    fn update_style_scheme(&self) {
        let imp = self.imp();

        let manager = adw::StyleManager::default();
        let scheme_name = if manager.is_dark() { "solarized-dark" } else { "solarized-light" };
        let scheme = gsv::StyleSchemeManager::default().scheme(scheme_name);
        imp.scheme.replace(scheme);

        self.apply_color_scheme(&*imp.resource_view);
        self.apply_color_scheme(&*imp.python_meson_view);
        self.apply_color_scheme(&*imp.python_view);
        self.apply_color_scheme(&*imp.rust_meson_view);
        self.apply_color_scheme(&*imp.rust_main_view);
        self.apply_color_scheme(&*imp.vala_meson_view);
        self.apply_color_scheme(&*imp.js_meson_view);
        self.apply_color_scheme(&*imp.js_view);
        self.apply_color_scheme(&*imp.c_meson_view);
    }

    fn init(&self) {
        let imp = self.imp();

        let settings = gio::Settings::new(config::APP_ID);
        settings.bind("doc-page", &*imp.languages_stack, "visible-child-name").build();

        imp.icon_size_16.set_from_icon_name(Some(&self.icon().name()));
        imp.icon_size_32.set_from_icon_name(Some(&self.icon().name()));
        imp.icon_size_64.set_from_icon_name(Some(&self.icon().name()));
        imp.tags_label.set_text(&self.icon().tags().join(", "));
        imp.window_title.set_title(&self.icon().name().replace("-symbolic", ""));

        let language_manager = gsv::LanguageManager::default();
        let xml_lang = language_manager.language("xml").unwrap();
        let py_lang = language_manager.language("python").unwrap();
        let meson_lang = language_manager.language("meson").unwrap();
        let rust_lang = language_manager.language("rust").unwrap();
        let js_lang = language_manager.language("js").unwrap();

        let resource = gresource_example(&self.icon().name());
        self.create_buffer(&xml_lang, &resource, &*imp.resource_view);

        // Python example
        self.create_buffer(&meson_lang, PYTHON_MESON_EXAMPLE, &*imp.python_meson_view);
        self.create_buffer(&py_lang, PYTHON_EXAMPLE, &*imp.python_view);

        // Rust example
        self.create_buffer(&meson_lang, RUST_MESON_EXAMPLE, &*imp.rust_meson_view);
        self.create_buffer(&rust_lang, RUST_MAIN_EXAMPLE, &*imp.rust_main_view);

        // Vala example
        self.create_buffer(&meson_lang, VALA_MESON_EXAMPLE, &*imp.vala_meson_view);

        // JS example
        self.create_buffer(&meson_lang, JS_MESON_EXAMPLE, &*imp.js_meson_view);
        self.create_buffer(&js_lang, JS_EXAMPLE, &*imp.js_view);

        // C example
        self.create_buffer(&meson_lang, C_MESON_EXAMPLE, &*imp.c_meson_view);

        self.update_style_scheme();

        let manager = adw::StyleManager::default();
        manager.connect_dark_notify(clone!(@weak self as this => move |_| {
            this.update_style_scheme();
        }));

        imp.include_label
            .connect_activate_link(clone!(@weak self as obj => @default-return gtk::Inhibit(false), move |_, name| {
                obj.imp().stack.set_visible_child_name(name);
                gtk::Inhibit(true)
            }));
    }

    fn setup_actions(&self) {
        let imp = self.imp();

        // setup actions
        let actions = gio::SimpleActionGroup::new();
        self.insert_action_group("export", Some(&actions));

        let deck = imp.deck.get();
        let stack = imp.stack.get();
        let overlay = imp.toast_overlay.get();
        let icon = self.icon();

        imp.as_system_row.set_visible(icon.is_system());
        imp.as_system_row.connect_activated(clone!(@weak deck, @weak stack => move |_| {
            stack.set_visible_child_name("in-platform");
            deck.navigate(adw::NavigationDirection::Forward);
        }));

        // Copy Icon Name action
        action!(
            actions,
            "copy-icon-name",
            clone!(@weak icon, @weak overlay => move |_, _| {
                icon.copy_name();

                let toast = adw::Toast::new(&gettext("Copied"));
                overlay.add_toast(&toast);
            })
        );

        // Switch view to: Include the icon in an App
        imp.in_app_row.connect_activated(clone!(@weak deck, @weak stack => move |_| {
            stack.set_visible_child_name("in-app");
            deck.navigate(adw::NavigationDirection::Forward);
        }));
        // Switch the view to Icon details
        action!(
            actions,
            "details",
            clone!(@weak deck => move |_, _| {
                deck.navigate(adw::NavigationDirection::Back);
            })
        );
        // Save GResource sample
        action!(
            actions,
            "save-resource",
            clone!(@weak self as window => move |_, _| {
                let export_dialog = gtk::FileChooserNative::new(
                    Some(&gettext("Export GResource example file")),
                    Some(&window),
                    gtk::FileChooserAction::Save,
                    Some(&gettext("Export")),
                    Some(&gettext("Cancel")),
                );

                let svg_filter = gtk::FileFilter::new();
                svg_filter.set_name(Some(&gettext("XML Document")));
                svg_filter.add_mime_type("application/xml");
                export_dialog.add_filter(&svg_filter);

                export_dialog.set_current_name(Path::new("resources.gresource.xml").to_str().unwrap());

                export_dialog.connect_response(clone!(@strong export_dialog as dialog => move |_, response| {
                    if response == gtk::ResponseType::Accept {
                        let destination = dialog.file().unwrap();

                        if let Err(err) = destination.replace_contents(GRESOURCE_EXAMPLE.as_bytes(), None,
                                                    false, gio::FileCreateFlags::NONE, gio::Cancellable::NONE) {
                            log::error!("Failed to save gresource example {}", err);
                        }
                    }
                    dialog.destroy();
                }));
                export_dialog.show();
            })
        );
        // Save As action
        action!(
            actions,
            "save-as",
            clone!(@weak icon, @weak self as window => move |_, _| {
                let export_dialog = gtk::FileChooserNative::new(
                    Some(&gettext("Export a symbolic icon")),
                    Some(&window),
                    gtk::FileChooserAction::Save,
                    Some(&gettext("Export")),
                    Some(&gettext("Cancel")),
                );

                let svg_filter = gtk::FileFilter::new();
                svg_filter.set_name(Some(&gettext("SVG images")));
                svg_filter.add_mime_type("image/svg+xml");
                export_dialog.add_filter(&svg_filter);

                let file_name = format!("{}.svg", icon.name());
                export_dialog.set_current_name(Path::new(&file_name).to_str().unwrap());

                export_dialog.connect_response(clone!(@weak icon, @strong export_dialog as dialog => move |_, response| {
                    if response == gtk::ResponseType::Accept {
                        let destination = dialog.file().unwrap();
                        if let Err(err) = icon.save(&destination) {
                            log::error!("Failed to export the icon {}", err);
                        }
                    }
                    dialog.destroy();
                }));
                export_dialog.show();
            })
        );

        // Derive icon
        action!(
            actions,
            "derive",
            clone!(@weak icon => move |_, _| {
                if let Err(err) = icon.derive() {
                    log::error!("Failed to derive the icon {}", err);
                }
            })
        );

        // Copy icon to clipboard action: copy-clipboard
        action!(
            actions,
            "copy-clipboard",
            clone!(@weak icon, @weak overlay => move |_, _| {
                let ctx = glib::MainContext::default();
                ctx.spawn_local(glib::clone!(@weak icon, @weak overlay => async move {
                    if let Err(err) = icon.copy().await {
                        log::error!("Failed to copy icon to clipboard: {:?}", err);
                    } else {
                        let toast = adw::Toast::new(&gettext("Copied"));
                        overlay.add_toast(&toast);
                    }
                }));
            })
        );
    }
}
