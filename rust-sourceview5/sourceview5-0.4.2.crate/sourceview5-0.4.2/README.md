# sourceview5-rs

[Gtk SourceView 5](https://gitlab.gnome.org/GNOME/gtksourceview/) Rust bindings

<div align="center">
    <img src="demo/screenshot.png" alt="Screenshot" />
</div>

A small demo is available in the [demo](./demo) subdirectory.

## Documentation

The versioned documentations can be found https://world.pages.gitlab.gnome.org/Rust/sourceview5-rs/
