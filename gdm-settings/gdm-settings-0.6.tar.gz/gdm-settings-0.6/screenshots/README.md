# Screenshots

![](screenshot-1.png#gh-light-mode-only)
![](screenshot-1-dark.png#gh-dark-mode-only)
![](screenshot-2.png#gh-light-mode-only)
![](screenshot-2-dark.png#gh-dark-mode-only)
![](screenshot-3.png#gh-light-mode-only)
![](screenshot-3-dark.png#gh-dark-mode-only)
![](screenshot-4.png#gh-light-mode-only)
![](screenshot-4-dark.png#gh-dark-mode-only)
![](screenshot-5.png#gh-light-mode-only)
![](screenshot-5-dark.png#gh-dark-mode-only)
![](screenshot-6.png#gh-light-mode-only)
![](screenshot-6-dark.png#gh-dark-mode-only)
![](screenshot-7.png#gh-light-mode-only)
![](screenshot-7-dark.png#gh-dark-mode-only)
![](screenshot-8.png#gh-light-mode-only)
![](screenshot-8-dark.png#gh-dark-mode-only)

